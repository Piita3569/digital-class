
import { useState } from "react";

export default function DigitalClassApp() {
  const [userRole, setUserRole] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);

  if (!loggedIn) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-blue-50 p-4">
        <div className="text-4xl font-bold mb-2">📘 Digital Class</div>
        <div className="mb-6 text-lg">¿Quién quiere ingresar?</div>
        <div className="space-x-4">
          <button onClick={() => { setUserRole('alumno'); setLoggedIn(true); }} className="px-4 py-2 bg-blue-600 text-white rounded">Alumno</button>
          <button onClick={() => { setUserRole('profesor'); setLoggedIn(true); }} className="px-4 py-2 bg-green-600 text-white rounded">Profesor</button>
          <button onClick={() => alert('Funcionalidad de apoderado en desarrollo')} className="px-4 py-2 bg-gray-400 text-white rounded">Apoderado</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white p-4">
      <div className="flex items-center justify-between mb-6">
        <div className="text-2xl font-bold">Hola, Usuario ({userRole})</div>
        <div className="rounded-full w-10 h-10 bg-gray-300"></div>
      </div>
      <div className="grid grid-cols-2 gap-4 mb-6">
        <button className="p-4 bg-blue-100 rounded shadow">Ramos</button>
        <button className="p-4 bg-green-100 rounded shadow">Calificaciones</button>
        <button className="p-4 bg-yellow-100 rounded shadow">Horario</button>
        <button className="p-4 bg-red-100 rounded shadow">Asistencia</button>
      </div>
      <div className="fixed bottom-4 w-full flex justify-around">
        <button className="p-2 bg-gray-200 rounded">Home</button>
        <button className="p-2 bg-gray-200 rounded">Calendario</button>
        <button className="p-2 bg-gray-200 rounded">Mensajes</button>
        <button className="p-2 bg-gray-200 rounded">Perfil</button>
      </div>
    </div>
  );
}
